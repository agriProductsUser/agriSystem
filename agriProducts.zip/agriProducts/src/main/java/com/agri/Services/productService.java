package com.agri.Services;

import com.agri.Entity.product;

public interface productService{
	
	public boolean saveProducts(product product);
	
}