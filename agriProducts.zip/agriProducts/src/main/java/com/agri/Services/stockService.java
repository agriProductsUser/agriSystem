package com.agri.Services;

import com.agri.Entity.stock;

public interface stockService {
	
	public boolean saveStock(stock stock);

}
