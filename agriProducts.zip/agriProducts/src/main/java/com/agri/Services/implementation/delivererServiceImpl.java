package com.agri.Services.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agri.Entity.deliverer;
import com.agri.Repository.delivererRepository;
import com.agri.Services.delivererService;

@Service
public class delivererServiceImpl implements delivererService {

	@Autowired
	delivererRepository delivererRepo;
	
	@Override
	public boolean saveDeliverer(deliverer deliverer) {
		// TODO Auto-generated method stub
		try {
			delivererRepo.save(deliverer);
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		
	}

	
}
