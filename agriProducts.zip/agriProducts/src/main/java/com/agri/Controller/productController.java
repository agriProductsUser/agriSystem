package com.agri.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.agri.Entity.product;
import com.agri.Services.productService;

@RestController
@RequestMapping("/product")
public class productController{
	
	@Autowired
	productService productService;
	
	
	@RequestMapping(value="/saveProduct", method= RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<?> saveProduct(@RequestBody product product1){
		try {
			
			return ResponseEntity.ok(productService.saveProducts(product1));
		
		}catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
	}
	
	
	
}